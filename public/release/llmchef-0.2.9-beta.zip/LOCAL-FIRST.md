# LLMChef Local Bundle

Serve this directory from a local static server and open it in your browser.

The app is static and local-first. Same-origin assets and loopback hosts are allowed by default. Remote hosts are blocked by the runtime fetch guard unless they are configured as providers, service URLs, MCP servers, marketplace sources, remote mods, or sync repositories.

Runnable Python blocks require Pyodide at /pyodide/v0.27.7/full/pyodide.js inside this bundle.
